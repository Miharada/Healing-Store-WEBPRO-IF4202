<div class="container">
    <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Tambah Data Pegawai 
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="nama">ID_Pegawai</label>
                            <input type="text" class="form-control" id="nama" name="nama">
                            
                        </div>
                        <div class="form-group">
                            <label for="nim">Nama</label>
                            <input type="text" class="form-control" id="nim" name="nim">
                            
                        </div>
                        <div class="form-group">
                            <label for="text">Alamat</label>
                            <input type="text" class="form-control" id="email" name="email">
                           
                        </div>
                        <div class="form-group">
                            <label for="text">No_HP</label>
                            <input type="text" class="form-control" id="email" name="email">
                           
                        </div>
                        <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah Data</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div> 
